package swing;

public interface EventCallBack {

    public void done();
}
